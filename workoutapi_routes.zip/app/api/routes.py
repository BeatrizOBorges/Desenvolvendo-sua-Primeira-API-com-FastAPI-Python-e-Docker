from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi_pagination import Page, paginate
from app.db.session import SessionLocal
from app.models.models import Atleta, CentroTreinamento, Categoria
from app.schemas.schemas import AtletaCreate, AtletaOut, CentroTreinamentoCreate, CentroTreinamentoOut, CategoriaCreate, CategoriaOut

router = APIRouter()


async def get_db():
    async with SessionLocal() as session:
        yield session


@router.post("/atletas", response_model=AtletaOut)
async def criar_atleta(atleta: AtletaCreate, db: AsyncSession = Depends(get_db)):
    novo_atleta = Atleta(**atleta.dict())
    try:
        db.add(novo_atleta)
        await db.commit()
        await db.refresh(novo_atleta)
        return novo_atleta
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=303,
            detail=f"Já existe um atleta cadastrado com o cpf: {atleta.cpf}"
        )


@router.get("/atletas", response_model=Page[AtletaOut])
async def listar_atletas(nome: str = None, cpf: str = None, db: AsyncSession = Depends(get_db)):
    query = select(Atleta).join(Atleta.centro_treinamento).join(Atleta.categoria)

    if nome:
        query = query.where(Atleta.nome.ilike(f"%{nome}%"))
    if cpf:
        query = query.where(Atleta.cpf == cpf)

    result = await db.execute(query)
    atletas = result.scalars().unique().all()
    return paginate(atletas)


@router.post("/centros", response_model=CentroTreinamentoOut)
async def criar_centro(centro: CentroTreinamentoCreate, db: AsyncSession = Depends(get_db)):
    novo_centro = CentroTreinamento(**centro.dict())
    db.add(novo_centro)
    await db.commit()
    await db.refresh(novo_centro)
    return novo_centro


@router.get("/centros", response_model=Page[CentroTreinamentoOut])
async def listar_centros(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(CentroTreinamento))
    centros = result.scalars().all()
    return paginate(centros)


@router.post("/categorias", response_model=CategoriaOut)
async def criar_categoria(categoria: CategoriaCreate, db: AsyncSession = Depends(get_db)):
    nova_categoria = Categoria(**categoria.dict())
    db.add(nova_categoria)
    await db.commit()
    await db.refresh(nova_categoria)
    return nova_categoria


@router.get("/categorias", response_model=Page[CategoriaOut])
async def listar_categorias(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Categoria))
    categorias = result.scalars().all()
    return paginate(categorias)
